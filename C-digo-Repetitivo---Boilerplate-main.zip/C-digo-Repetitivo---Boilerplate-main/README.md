# p5.play-boilerplate-código repetitivo
Código Repetitivo para p5.play
